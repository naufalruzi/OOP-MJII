package com.example.practical_assesment;

abstract class SurfaceAreaShape extends MainActivity{
    abstract void getInput(int x,int y);
    abstract void calculate();
    abstract void displayOutput(String x);
}
